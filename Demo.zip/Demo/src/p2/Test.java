package p2;

import p1.Bike;
import p1.Car;

public class Test {

	public static void main(String[] args) {

		Car car = new Car();
		car.start();

		Bike bike = something.getBean("bike");
		bike.start();

	}

}
