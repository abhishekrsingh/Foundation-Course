package p1;

public class Car {

	public void start() {
		System.out.println("Car is running");
	}

}
