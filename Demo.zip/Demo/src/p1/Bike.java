package p1;

public class Bike {

	public void start() {
		System.out.println("Bike is running");
	}

}
