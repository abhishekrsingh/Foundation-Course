package com.shad.model;

public interface Processor {

	void doProcessing();

}
